"""
ai_engine/orchestrator/pipeline.py
Shared data classes and constants for the SabiLens scan pipeline.
All agent runners and the fusion engine read from this file.
"""

from dataclasses import dataclass, field


@dataclass
class AgentSignal:
    """Output produced by one agent after processing a scan request."""
    agent_id:   str    # which agent produced this — "vision", "ocr", "regulatory", or "fusion"
    available:  bool   # False if the module is offline or not yet integrated
    confidence: float  # normalised score 0.0–1.0
    payload:    dict   # full result dict from the agent
    mocked:     bool = False  # True when a placeholder confidence was used instead of a real run


@dataclass
class PipelineResult:
    """Complete output of one orchestrated scan — returned to D1 Backend."""
    vision_signal:     AgentSignal   # visual classification signal from A1
    ocr_signal:        AgentSignal   # OCR text extraction signal from A2
    regulatory_signal: AgentSignal   # NAFDAC database verification signal from A3
    fusion_signal:     AgentSignal   # fused verdict signal from A4
    final_verdict:     str   = ""    # AUTHENTIC | SUSPICIOUS | FAKE
    final_score:       float = 0.0   # fused confidence score 0.0–1.0
    final_severity:    str   = ""    # NONE | WARNING | HIGH | CRITICAL
    summary:           str   = ""    # one-line verdict for D3 mobile display
    detail:            str   = ""    # full sentence for D6 voice translation
    signals_used:      list  = field(default_factory=list)  # agent IDs that contributed real weight


# ── Pipeline constants ─────────────────────────────────────────────────────────

# Call order: OCR extracts the NAFDAC number → regulatory verifies it → vision confirms → fusion combines
PIPELINE_ORDER = ["ocr", "regulatory", "vision", "fusion"]

# Fusion weights — regulatory carries the most authority as it checks the NAFDAC database directly
SIGNAL_WEIGHTS = {
    "regulatory": 0.40,  # ground truth — NAFDAC DB lookup + expiry check + category match
    "vision":     0.35,  # physical packaging evidence — label and product appearance
    "ocr":        0.25,  # OCR read quality — confidence of text extracted from the label
}

# Placeholder confidence injected for vision and ocr until those modules are integrated
MOCK_CONFIDENCE = 0.80

# Fused score thresholds that determine the final verdict label
THRESHOLD_AUTHENTIC  = 0.75  # score >= 0.75 → AUTHENTIC (GREEN)
THRESHOLD_SUSPICIOUS = 0.45  # score 0.45–0.74 → SUSPICIOUS (AMBER); below → FAKE (RED)

# Regulatory status codes that force an immediate FAKE verdict — weighted formula is bypassed entirely
CRITICAL_STATUSES = {"NOT_FOUND", "SUBCATEGORY_MISMATCH", "AGENT_ERROR"}