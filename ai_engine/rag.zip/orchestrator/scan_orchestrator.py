"""
ai_engine/orchestrator/scan_orchestrator.py
Coordinates vision (A1), OCR (A2), regulatory (A3), and fusion (A4) agents
for every product label scan in SabiLens.
D1 Backend creates one ScanOrchestrator instance at startup and calls scan() per request.
"""

from ai_engine.agent.verification_agent import NAFDACVerificationAgent
from ai_engine.orchestrator.pipeline    import (
    AgentSignal, PipelineResult,
    SIGNAL_WEIGHTS, MOCK_CONFIDENCE,
    THRESHOLD_AUTHENTIC, THRESHOLD_SUSPICIOUS, CRITICAL_STATUSES,
)


class ScanOrchestrator:
    """
    Runs all four agents in sequence for one product scan and returns a fused verdict.

    Call sequence per scan:
        ocr (A2) → regulatory (A3) → vision (A1) → fusion (A4)

    Vision and OCR signals are mocked at 0.80 confidence until those modules are
    integrated. Pass real confidence values once they are ready — no other changes needed.

    Usage:
        orchestrator = ScanOrchestrator()                   # once at startup

        result = orchestrator.scan("A8-4114", "corn flakes")
        print(result.final_verdict)   # AUTHENTIC
        print(result.final_score)     # 0.88

        # Once A1 and A2 are integrated:
        result = orchestrator.scan(
            nafdac_no        = "A8-4114",
            scanned_category = "corn flakes",
            vision_confidence = 0.93,
            ocr_confidence    = 0.91,
        )

        # Full plain-text reasoning trace for demos and D5 audit panel:
        print(orchestrator.explain("A8-4114", "corn flakes"))
    """

    def __init__(self):
        self._regulatory_agent = NAFDACVerificationAgent()  # loads ChromaDB and sentence-transformer once at startup

    def scan(
        self,
        nafdac_no:         str,
        scanned_category:  str,
        vision_confidence: float | None = None,  # real A1 visual confidence; None → mocked at 0.80
        ocr_confidence:    float | None = None,  # real A2 OCR confidence;    None → mocked at 0.80
    ) -> PipelineResult:
        """
        Run all agents in pipeline order and return a complete PipelineResult.

        Regulatory CRITICAL verdicts (NOT_FOUND, SUBCATEGORY_MISMATCH) bypass the
        weighted fusion formula and immediately set the verdict to FAKE.
        """
        ocr_signal        = self._run_ocr(nafdac_no, ocr_confidence)              # step 1 — collect OCR signal
        regulatory_signal = self._run_regulatory(nafdac_no, scanned_category)     # step 2 — NAFDAC verification
        vision_signal     = self._run_vision(scanned_category, vision_confidence)  # step 3 — collect vision signal
        fusion_signal     = self._run_fusion(vision_signal, ocr_signal, regulatory_signal)  # step 4 — fuse all three

        return PipelineResult(
            vision_signal     = vision_signal,
            ocr_signal        = ocr_signal,
            regulatory_signal = regulatory_signal,
            fusion_signal     = fusion_signal,
            final_verdict     = fusion_signal.payload["verdict"],
            final_score       = fusion_signal.payload["fused_score"],
            final_severity    = fusion_signal.payload["severity"],
            summary           = fusion_signal.payload["summary"],   # forwarded from regulatory — one-line verdict
            detail            = fusion_signal.payload["detail"],    # forwarded from regulatory — full sentence for D6
            signals_used      = [                                    # only agents that had non-zero weight
                agent_id for agent_id in ["vision", "ocr", "regulatory"]
                if fusion_signal.payload["signal_breakdown"][agent_id]["weight"] > 0
            ],
        )

    # ── Agent runners ──────────────────────────────────────────────────────────
    # Each runner returns one AgentSignal with a standardised confidence and payload.
    # When a module is not yet integrated, mocked=True and confidence=MOCK_CONFIDENCE.

    def _run_ocr(self, nafdac_no: str, real_confidence: float | None) -> AgentSignal:
        """Collect the OCR signal from A2. Returns a mock signal until A2 is integrated."""
        mocked     = real_confidence is None
        confidence = MOCK_CONFIDENCE if mocked else real_confidence
        return AgentSignal(
            agent_id   = "ocr",
            available  = True,
            confidence = confidence,
            mocked     = mocked,
            payload    = {
                "ocr_confidence": confidence,
                "raw_nafdac_no" : nafdac_no,  # passed through unchanged to the regulatory agent
            },
        )

    def _run_regulatory(self, nafdac_no: str, scanned_category: str) -> AgentSignal:
        """
        Run the A3 NAFDAC regulatory verification agent and package the result as an AgentSignal.
        This is always a real call — the regulatory agent is never mocked.
        """
        verdict = self._regulatory_agent.verify(nafdac_no, scanned_category)  # runs lookup → expiry → alignment
        return AgentSignal(
            agent_id   = "regulatory",
            available  = True,
            confidence = verdict.verification_score,  # 0.0 (NOT_FOUND) to 1.0 (VERIFIED)
            mocked     = False,
            payload    = {
                "verification_score": verdict.verification_score,
                "status_code"       : verdict.status_code,    # VERIFIED | EXPIRED | NOT_FOUND | SUBCATEGORY_MISMATCH
                "severity"          : verdict.severity,        # NONE | WARNING | HIGH | CRITICAL
                "verified"          : verdict.verified,
                "summary"           : verdict.summary,
                "detail"            : verdict.detail,
                "matched_record"    : verdict.matched_record,  # full DB record or None
                "expiry_check"      : verdict.expiry_check,    # expiry layer result dict
                "alignment"         : verdict.alignment,       # category match layer result dict
                "reasoning_trace"   : [                        # each step the ReAct engine took
                    {
                        "thought"            : step.thought,
                        "action"             : step.action,
                        "action_input"       : step.action_input,
                        "observation_summary": step.observation_summary,
                    }
                    for step in verdict.reasoning_trace
                ],
                "tools_called" : verdict.tools_called,   # e.g. ["lookup_nafdac", "check_expiry", "check_alignment"]
                "fallback_used": verdict.fallback_used,  # True if semantic_search was used instead of direct lookup
            },
        )

    def _run_vision(self, scanned_category: str, real_confidence: float | None) -> AgentSignal:
        """Collect the vision signal from A1. Returns a mock signal until A1 is integrated."""
        mocked     = real_confidence is None
        confidence = MOCK_CONFIDENCE if mocked else real_confidence
        return AgentSignal(
            agent_id   = "vision",
            available  = True,
            confidence = confidence,
            mocked     = mocked,
            payload    = {
                "visual_confidence": confidence,
                "detected_category": scanned_category,  # placeholder until A1 classifies the image
            },
        )

    def _run_fusion(
        self,
        vision_signal:     AgentSignal,
        ocr_signal:        AgentSignal,
        regulatory_signal: AgentSignal,
    ) -> AgentSignal:
        """
        Fuse vision, OCR, and regulatory signals into a final verdict using weighted scoring.

        If the regulatory agent returns a CRITICAL status (NOT_FOUND or SUBCATEGORY_MISMATCH),
        the weighted formula is bypassed entirely and the verdict is forced to FAKE.
        This prevents high vision/OCR confidence from masking a definitive fake signal.
        """
        regulatory_status = regulatory_signal.payload["status_code"]

        if regulatory_status in CRITICAL_STATUSES:
            # Critical override — regulatory has definitive evidence, no formula needed
            fused_score = regulatory_signal.confidence  # 0.0 for NOT_FOUND, 0.2 for SUBCATEGORY_MISMATCH
            verdict     = "FAKE"
            severity    = "CRITICAL"
            summary     = regulatory_signal.payload["summary"]
            detail      = regulatory_signal.payload["detail"]
            breakdown   = {
                "regulatory": {"score": regulatory_signal.confidence, "weight": 1.0},  # full weight on override
                "vision"    : {"score": vision_signal.confidence,     "weight": 0.0},  # zeroed to show override fired
                "ocr"       : {"score": ocr_signal.confidence,        "weight": 0.0},
            }

        else:
            # Normal fusion — weighted average of all three signals
            weights     = dict(SIGNAL_WEIGHTS)  # copy so we don't mutate the module constant
            scores      = {
                "regulatory": regulatory_signal.confidence,
                "vision"    : vision_signal.confidence,
                "ocr"       : ocr_signal.confidence,
            }
            total_weight = sum(weights[k] for k in scores)  # always 1.0, guards against future config changes
            fused_score  = round(
                sum((weights[k] / total_weight) * scores[k] for k in scores), 4
            )

            if fused_score >= THRESHOLD_AUTHENTIC:
                verdict  = "AUTHENTIC"
                severity = regulatory_signal.payload.get("severity", "NONE")  # preserve WARNING if near-expiry
            elif fused_score >= THRESHOLD_SUSPICIOUS:
                verdict  = "SUSPICIOUS"
                severity = "WARNING"
            else:
                verdict  = "FAKE"
                severity = "HIGH"

            summary   = regulatory_signal.payload["summary"]
            detail    = regulatory_signal.payload["detail"]
            breakdown = {
                "regulatory": {"score": regulatory_signal.confidence, "weight": round(weights["regulatory"] / total_weight, 4)},
                "vision"    : {"score": vision_signal.confidence,     "weight": round(weights["vision"]     / total_weight, 4)},
                "ocr"       : {"score": ocr_signal.confidence,        "weight": round(weights["ocr"]        / total_weight, 4)},
            }

        return AgentSignal(
            agent_id   = "fusion",
            available  = True,
            confidence = fused_score,
            mocked     = False,
            payload    = {
                "verdict"           : verdict,
                "fused_score"       : fused_score,
                "severity"          : severity,
                "summary"           : summary,
                "detail"            : detail,
                "override_applied"  : regulatory_status in CRITICAL_STATUSES,  # True when fusion was bypassed
                "signal_breakdown"  : breakdown,        # per-agent score and weight for D5 audit display
                "vision_mocked"     : vision_signal.mocked,  # tells D5 which signals were real vs placeholder
                "ocr_mocked"        : ocr_signal.mocked,
            },
        )

    # ── Developer utility ──────────────────────────────────────────────────────

    def explain(self, nafdac_no: str, scanned_category: str) -> str:
        """
        Run a full scan and return a formatted plain-text report.
        Shows the regulatory reasoning trace and fusion breakdown in one readable block.
        Useful for instructor demos, rag_query.py, and the D5 audit panel.
        """
        result            = self.scan(nafdac_no, scanned_category)
        regulatory_trace  = result.regulatory_signal.payload.get("reasoning_trace", [])
        breakdown         = result.fusion_signal.payload["signal_breakdown"]

        lines = [
            "",
            "SABILENS SCAN — Orchestrator Report",
            "=" * 60,
            f"NAFDAC      : {nafdac_no}",
            f"Category    : {scanned_category}",
            f"Signals     : vision={'mocked' if result.vision_signal.mocked else 'real'}"
            f"  ocr={'mocked' if result.ocr_signal.mocked else 'real'}"
            f"  regulatory=real",
            "",
            "REGULATORY AGENT REASONING (A3)",
            "-" * 40,
        ]
        for i, step in enumerate(regulatory_trace, 1):
            lines += [
                f"  Step {i} | {step['action']}",
                f"    Thought : {step['thought']}",
                f"    Result  : {step['observation_summary']}",
                "",
            ]
        lines += [
            "FUSION RESULT (A4)",
            "-" * 40,
            f"  regulatory : score={result.regulatory_signal.confidence}  weight={breakdown['regulatory']['weight']}",
            f"  vision     : score={result.vision_signal.confidence}  weight={breakdown['vision']['weight']}",
            f"  ocr        : score={result.ocr_signal.confidence}  weight={breakdown['ocr']['weight']}",
            f"  Override applied : {result.fusion_signal.payload['override_applied']}",
            "",
            "FINAL VERDICT",
            "-" * 40,
            f"  Verdict  : {result.final_verdict}",
            f"  Score    : {result.final_score}",
            f"  Severity : {result.final_severity}",
            f"  Summary  : {result.summary}",
            "",
        ]
        return "\n".join(lines)