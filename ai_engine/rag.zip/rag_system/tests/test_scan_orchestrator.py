"""
ai_engine/tests/test_scan_orchestrator.py
Tests for ScanOrchestrator — covers all verdict paths and signal fusion logic.
All agent calls are mocked so no ChromaDB or model is required.
"""

import pytest
from unittest.mock import MagicMock, patch
from ai_engine.orchestrator.scan_orchestrator import ScanOrchestrator
from ai_engine.orchestrator.pipeline          import AgentSignal, PipelineResult, MOCK_CONFIDENCE


# ── AgentVerdict stub factory ──────────────────────────────────────────────────

def _make_regulatory_verdict(status: str, score: float, severity: str, near_expiry: bool = False):
    """Build a minimal AgentVerdict-like mock for injecting into the orchestrator."""
    v = MagicMock()
    v.verification_score = score
    v.status_code        = status
    v.severity           = severity
    v.verified           = score >= 0.75
    v.summary            = f"Test summary ({status})"
    v.detail             = f"Test detail ({status})"
    v.matched_record     = {"product_name": "TEST PRODUCT", "subcategory": "Cereals and Cereal Products"}
    v.expiry_check       = {"is_near_expiry": near_expiry, "is_valid": True, "severity": "WARNING" if near_expiry else "NONE", "message": ""}
    v.alignment          = {"is_match": True}
    v.reasoning_trace    = []
    v.tools_called       = ["lookup_nafdac", "check_expiry", "check_alignment"]
    v.fallback_used      = False
    return v


def _make_orchestrator(regulatory_verdict_mock) -> ScanOrchestrator:
    """Return a ScanOrchestrator whose regulatory agent is replaced with a mock."""
    orc = ScanOrchestrator.__new__(ScanOrchestrator)   # skip __init__ (avoids loading ChromaDB)
    orc._regulatory_agent = MagicMock()
    orc._regulatory_agent.verify.return_value = regulatory_verdict_mock
    return orc


# ═══════════════════════════════════════════════════════════════════
# Class 1 — Verdict paths
# ═══════════════════════════════════════════════════════════════════

class TestVerdictPaths:
    """Tests for AUTHENTIC, SUSPICIOUS, FAKE, and CRITICAL override verdicts."""

    def test_authentic_when_regulatory_verified_and_high_scores(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "corn flakes")
        assert result.final_verdict == "AUTHENTIC"

    def test_fake_when_regulatory_not_found(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("NOT_FOUND", 0.0, "CRITICAL"))
        result = orc.scan("FAKE-9999", "cereal")
        assert result.final_verdict == "FAKE"

    def test_fake_when_regulatory_mismatch(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("SUBCATEGORY_MISMATCH", 0.2, "CRITICAL"))
        result = orc.scan("A8-4114", "cosmetics")
        assert result.final_verdict == "FAKE"

    def test_fake_when_regulatory_agent_error(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("AGENT_ERROR", 0.0, "CRITICAL"))
        result = orc.scan("A8-4114", "cereal")
        assert result.final_verdict == "FAKE"

    def test_authentic_near_expiry_still_authentic(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED_NEAR_EXPIRY", 0.85, "WARNING", near_expiry=True))
        result = orc.scan("01-0132", "tea")
        assert result.final_verdict == "AUTHENTIC"

    def test_severity_propagated_from_regulatory_for_authentic(self):
        """Near-expiry WARNING from the regulatory agent must carry through to final severity."""
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED_NEAR_EXPIRY", 0.85, "WARNING"))
        result = orc.scan("01-0132", "tea")
        assert result.final_severity == "WARNING"


# ═══════════════════════════════════════════════════════════════════
# Class 2 — Critical override
# ═══════════════════════════════════════════════════════════════════

class TestCriticalOverride:
    """Tests that a CRITICAL regulatory status bypasses the fusion formula."""

    def test_override_applied_on_not_found(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("NOT_FOUND", 0.0, "CRITICAL"))
        result = orc.scan("FAKE-9999", "cereal")
        assert result.fusion_signal.payload["override_applied"] is True

    def test_override_applied_on_mismatch(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("SUBCATEGORY_MISMATCH", 0.2, "CRITICAL"))
        result = orc.scan("A8-4114", "cosmetics")
        assert result.fusion_signal.payload["override_applied"] is True

    def test_override_not_applied_on_verified(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        assert result.fusion_signal.payload["override_applied"] is False

    def test_vision_and_ocr_weights_zero_on_override(self):
        """When override fires, vision and OCR weights must be 0 in the breakdown."""
        orc    = _make_orchestrator(_make_regulatory_verdict("NOT_FOUND", 0.0, "CRITICAL"))
        result = orc.scan("FAKE-9999", "cereal")
        breakdown = result.fusion_signal.payload["signal_breakdown"]
        assert breakdown["vision"]["weight"] == 0.0
        assert breakdown["ocr"]["weight"]    == 0.0

    def test_fused_score_equals_regulatory_score_on_override(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("SUBCATEGORY_MISMATCH", 0.2, "CRITICAL"))
        result = orc.scan("A8-4114", "cosmetics")
        assert result.final_score == 0.2


# ═══════════════════════════════════════════════════════════════════
# Class 3 — Signal fusion
# ═══════════════════════════════════════════════════════════════════

class TestSignalFusion:
    """Tests for weighted score calculation when no override applies."""

    def test_fused_score_is_weighted_combination(self):
        """With all mocked signals: (1.0*0.4 + 0.8*0.35 + 0.8*0.25) = 0.88"""
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        assert abs(result.final_score - 0.88) < 0.01

    def test_fused_score_with_real_vision_and_ocr(self):
        """With vision=0.95, ocr=0.90: (1.0*0.4 + 0.95*0.35 + 0.90*0.25) = 0.9575"""
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal", vision_confidence=0.95, ocr_confidence=0.90)
        assert abs(result.final_score - 0.9575) < 0.01

    def test_signal_breakdown_weights_sum_to_one(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        breakdown = result.fusion_signal.payload["signal_breakdown"]
        total     = breakdown["regulatory"]["weight"] + breakdown["vision"]["weight"] + breakdown["ocr"]["weight"]
        assert abs(total - 1.0) < 0.001

    def test_suspicious_band(self):
        """Regulatory score of 0.1 with mocked vision/ocr should land in SUSPICIOUS band."""
        orc    = _make_orchestrator(_make_regulatory_verdict("EXPIRED", 0.1, "HIGH"))
        result = orc.scan("A8-4114", "cereal")
        # (0.1*0.4 + 0.8*0.35 + 0.8*0.25) = 0.48 → SUSPICIOUS
        assert result.final_verdict == "SUSPICIOUS"


# ═══════════════════════════════════════════════════════════════════
# Class 4 — Mocked signals
# ═══════════════════════════════════════════════════════════════════

class TestMockedSignals:
    """Tests that vision and OCR mock flags are set and cleared correctly."""

    def test_vision_mocked_when_not_provided(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        assert result.vision_signal.mocked is True

    def test_ocr_mocked_when_not_provided(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        assert result.ocr_signal.mocked is True

    def test_vision_not_mocked_when_provided(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal", vision_confidence=0.93)
        assert result.vision_signal.mocked is False

    def test_ocr_not_mocked_when_provided(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal", ocr_confidence=0.88)
        assert result.ocr_signal.mocked is False

    def test_mock_confidence_value_is_used(self):
        orc    = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        result = orc.scan("A8-4114", "cereal")
        assert result.vision_signal.confidence == MOCK_CONFIDENCE
        assert result.ocr_signal.confidence    == MOCK_CONFIDENCE


# ═══════════════════════════════════════════════════════════════════
# Class 5 — PipelineResult shape
# ═══════════════════════════════════════════════════════════════════

class TestPipelineResultShape:
    """Tests that the PipelineResult returned by scan() has the expec~ted structure."""

    def _scan(self):
        orc = _make_orchestrator(_make_regulatory_verdict("VERIFIED", 1.0, "NONE"))
        return orc.scan("A8-4114", "cereal")

    def test_result_has_all_agent_signals(self):
        result = self._scan()
        assert result.vision_signal.agent_id     == "vision"
        assert result.ocr_signal.agent_id        == "ocr"
        assert result.regulatory_signal.agent_id == "regulatory"
        assert result.fusion_signal.agent_id     == "fusion"

    def test_final_verdict_is_string(self):
        assert isinstance(self._scan().final_verdict, str)

    def test_final_score_between_0_and_1(self):
        score = self._scan().final_score
        assert 0.0 <= score <= 1.0

    def test_summary_is_string(self):
        assert isinstance(self._scan().summary, str)

    def test_detail_is_string(self):
        assert isinstance(self._scan().detail, str)

    def test_regulatory_payload_has_reasoning_trace(self):
        result = self._scan()
        assert "reasoning_trace" in result.regulatory_signal.payload

    def test_regulatory_payload_has_tools_called(self):
        result = self._scan()
        assert "tools_called" in result.regulatory_signal.payload